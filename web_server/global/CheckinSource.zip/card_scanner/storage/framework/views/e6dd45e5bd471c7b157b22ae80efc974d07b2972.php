<?php $__env->startSection('content'); ?>
<div id="content" class="page-main">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-status bg-blue"></div>
					<div class="card-header">
						<h3 class="card-title text-uppercase">Chọn lớp</h3>
					</div>
					<div class="card-body">
						<form action="">
							<div class="form-group">
								<select  id="dslop" class="form-control">
								<?php if($dslop): ?>
									<?php $__empty_1 = true; $__currentLoopData = $dslop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<option value="<?php echo e($lop->malop); ?>"><?php echo e($lop->tenlop); ?> </option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<option value="">Không có dữ liệu </option>
									<?php endif; ?>
									<?php endif; ?>
								
									<!-- <option value="">Optio illo asperiores dignissimos! Laudantium.</option>
									<option value="">At veritatis sunt officiis, nesciunt.</option> -->
								</select>
							</div>
							<div class="text-right">
								<button class="btn btn-primary btn-nap"><i class="fe fe-arrow-down-circle"></i> Nạp danh sách lớp</button>
							</div>
						</form>
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="card">
					<div class="card-status bg-blue"></div>
					<div class="card-header">
						<h3 class="card-title text-uppercase">Danh sách sinh viên <span id="tenlop"></span> </h3>
					</div>
					<div class="card-body">
						<div class="table-responsive">
							<table class="table table-hover">
								<thead>
									<tr>
										<th>STT</th>
										<th>Họ tên</th>
										<th class="text-right">Chức năng</th>
									</tr>
								</thead>
								<tbody id="body-list">
									

								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>

	$('.btn-nap').click(function(e){
		e.preventDefault();
		var dslop = $('#dslop').val();
		$.ajax({
			type: "get",
			url: "<?php echo e(route('ds_sinhvien_lop')); ?>",
			data: {"malop" : dslop},
			success: function (response) {
				$("#body-list").html(response['ds']);
				$("#tenlop").html(response['tenlop']);
				console.log(response['tenlop']);
			}
		});
	})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>