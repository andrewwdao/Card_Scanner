﻿
<?php $__env->startSection('content'); ?>
<div id="content" class="page-main">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-status bg-blue"></div>
					<div class="card-header">
						<h3 class="card-title text-uppercase">Thao tác</h3>
					</div>
					<div class="card-body">
						<form action="" method="post">
							<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
							<div class="row">
								<div class="col-lg-6">
									<div class="form-group">
										<label>Mã sinh viên</label>
										<input type="text" class="form-control" disabled value="<?php echo e($data->masv); ?>" >
									</div>
								</div>
								<div class="col-lg-6">
									<div class="form-group">
										<label>Tên sinh viên</label>
										<input type="text" class="form-control" value="<?php echo e($data->hoten); ?>" name="hoten">
									</div>
								</div>
								<div class="col-lg-6">
										<div class="form-group">
											<label>Giới tính</label>
											<select name="gioitinh" id="" class="form-control">
												<option <?php if($data->gioitinh=='Nam'): ?> selected  <?php endif; ?> value="Nam">Nam</option>
												<option <?php if($data->gioitinh=='Nữ'): ?> selected  <?php endif; ?> value="Nữ">Nữ</option>
											</select>
										</div>
								</div>
								<div class="col-lg-6">
										<div class="form-group">
											<label>Lớp</label>
											<select name="malop" id="" class="form-control">
												<?php $__currentLoopData = $lop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option <?php if($data->malop==$val->malop): ?> selected <?php endif; ?> value="<?php echo e($val->malop); ?>"><?php echo e($val->tenlop); ?></option>
												
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
										</div>
								</div>
							</div>
							<div class="text-right">
								<button class="btn btn-primary"><i class="fe fe-arrow-down-circle"></i> Chỉnh sửa</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>