<?php $__env->startSection('content'); ?>
<div id="content" class="page-main">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<div class="card">
					<div class="card-status bg-blue"></div>
					<div class="card-header">
						<h3 class="card-title text-uppercase">Training cho sinh viên <?php echo e($sinhvien->hoten); ?></h3>
					</div>
					<div class="card-body">
						<div class="form-group">
							
							<form action="<?php echo e(route('traindata',[$mssv])); ?>" enctype="multipart/form-data" method="post">
							<?php echo e(csrf_field()); ?>

								<div class="form-group">
							
									<div class="custom-file">
										<input id="train-data" type="file" class="custom-file-input" name="upload[]" multiple="multiple">
										
										<label class="custom-file-label" id="count">Nạp ảnh (Tối thiểu 3 ảnh)</label>
									</div>
								</div>

								<div class="form-group">
									<input class="btn btn-primary pull-right btn-lg " type="submit" name="submit" value="Upload ảnh">
								</div>
								<div class="form-group pt-3">
									<?php if(session()->has('result')): ?>
									<p>Danh sách upload</p>
									<ul class="list-group">
									
										<?php if(count(session()->get('result')['done']) > 0): ?>
										<?php $__currentLoopData = session()->get('result')['done']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="list-group-item list-group-item-success"><?php echo e($user); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
										<?php if(count(session()->get('result')['fail']) > 0): ?>
										<?php $__currentLoopData = session()->get('result')['fail']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li class="list-group-item list-group-item-danger"><?php echo e($user); ?></li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									
									</ul>
									<?php endif; ?>
								</div>
							</form>
						</div>
					
					</div>
				</div>
			</div>
			
		</div>
	</div>
</div>

<script>
$(document).ready(function () {
	$("#train-data").change(function(){
		$("#count").text('Đã nạp '+$("input:file")[0].files.length +' ảnh')
	});
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('masterlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>